using BankProductsAPI.Attributes;
using BankProductsAPI.Models;
using BankProductsAPI.Services;
using Microsoft.AspNetCore.Mvc;

namespace BankProductsAPI.Controllers;

[ApiController]
[Route("api/products")]
public class BankProductsController : ControllerBase
{
    private readonly IBankProductService _products;

    public BankProductsController(IBankProductService products)
    {
        _products = products;
    }

    // Admin, Manager, Client — просмотр
    [HttpGet]
    [BasicAuthentication]
    [MyAuthorize("Admin", "Manager", "Client")]
    public ActionResult<IEnumerable<BankProduct>> GetAll() => Ok(_products.GetAll());

    [HttpGet("{id:int}")]
    [BasicAuthentication]
    [MyAuthorize("Admin", "Manager", "Client")]
    public ActionResult<BankProduct> GetById(int id)
    {
        var product = _products.GetById(id);
        return product is null ? NotFound() : Ok(product);
    }

    // Admin, Manager — создание
    [HttpPost]
    [BasicAuthentication]
    [MyAuthorize("Admin", "Manager")]
    public ActionResult<BankProduct> Create([FromBody] BankProduct product)
    {
        var created = _products.Create(product);
        return CreatedAtAction(nameof(GetById), new { id = created.Id }, created);
    }

    // Admin, Manager — изменение
    [HttpPut("{id:int}")]
    [BasicAuthentication]
    [MyAuthorize("Admin", "Manager")]
    public IActionResult Update(int id, [FromBody] BankProduct product)
    {
        return _products.Update(id, product) ? NoContent() : NotFound();
    }

    // Только Admin — удаление
    [HttpDelete("{id:int}")]
    [BasicAuthentication]
    [MyAuthorize("Admin")]
    public IActionResult Delete(int id)
    {
        return _products.Delete(id) ? NoContent() : NotFound();
    }

    // Информация о текущем пользователе (демонстрация Claims)
    [HttpGet("me")]
    [BasicAuthentication]
    [MyAuthorize]
    public IActionResult Me()
    {
        return Ok(new
        {
            Name = User.Identity?.Name,
            AuthenticationType = User.Identity?.AuthenticationType,
            Claims = User.Claims.Select(c => new { c.Type, c.Value })
        });
    }
}
