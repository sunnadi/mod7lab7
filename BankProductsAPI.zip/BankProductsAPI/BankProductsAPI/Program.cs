using Microsoft.OpenApi.Models;
using BankProductsAPI.Services;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();

// Сервисы (Singleton — данные хранятся в памяти)
builder.Services.AddSingleton<IUserService, UserService>();
builder.Services.AddSingleton<IBankProductService, BankProductService>();

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo { Title = "BankProductsAPI", Version = "v1" });

    // Кнопка Authorize (Basic) в Swagger UI
    c.AddSecurityDefinition("basic", new OpenApiSecurityScheme
    {
        Name = "Authorization",
        Type = SecuritySchemeType.Http,
        Scheme = "basic",
        In = ParameterLocation.Header,
        Description = "Basic Authentication. Например: AdminUser / Admin123"
    });
    c.AddSecurityRequirement(new OpenApiSecurityRequirement
    {
        {
            new OpenApiSecurityScheme
            {
                Reference = new OpenApiReference { Type = ReferenceType.SecurityScheme, Id = "basic" }
            },
            Array.Empty<string>()
        }
    });
});

var app = builder.Build();

app.UseSwagger();
app.UseSwaggerUI();

app.MapControllers();

app.Run();
