using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace BankProductsAPI.Attributes;

/// <summary>
/// Авторизация по ролям. Использование: [MyAuthorize("Admin", "Manager")].
/// Не аутентифицирован -> 401, нет нужной роли -> 403.
/// </summary>
[AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, AllowMultiple = false)]
public class MyAuthorizeAttribute : Attribute, IAuthorizationFilter, IOrderedFilter
{
    private readonly string[] _roles;

    // Выполняется после BasicAuthentication
    public int Order { get; set; } = 2;

    public MyAuthorizeAttribute(params string[] roles)
    {
        _roles = roles;
    }

    public void OnAuthorization(AuthorizationFilterContext context)
    {
        // Если предыдущий фильтр уже вернул результат (например, 401) — ничего не делаем
        if (context.Result is not null) return;

        var user = context.HttpContext.User;

        // 1. Пользователь аутентифицирован?
        if (user.Identity is not { IsAuthenticated: true })
        {
            context.HttpContext.Response.Headers["WWW-Authenticate"] = "Basic realm=\"BankProductsAPI\"";
            context.Result = new UnauthorizedResult(); // 401
            return;
        }

        // 2. Роли не указаны — достаточно аутентификации
        if (_roles.Length == 0) return;

        // 3. Есть ли хотя бы одна из требуемых ролей?
        if (!_roles.Any(user.IsInRole))
        {
            // 403 (StatusCodeResult, т.к. ForbidResult требует зарегистрированную схему аутентификации)
            context.Result = new StatusCodeResult(StatusCodes.Status403Forbidden);
        }
    }
}
