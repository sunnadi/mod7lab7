using BankProductsAPI.Models;

namespace BankProductsAPI.Services;

public interface IBankProductService
{
    IEnumerable<BankProduct> GetAll();
    BankProduct? GetById(int id);
    BankProduct Create(BankProduct product);
    bool Update(int id, BankProduct product);
    bool Delete(int id);
}
