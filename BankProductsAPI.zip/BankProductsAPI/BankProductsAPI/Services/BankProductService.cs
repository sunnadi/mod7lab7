using BankProductsAPI.Models;

namespace BankProductsAPI.Services;

public class BankProductService : IBankProductService
{
    private readonly List<BankProduct> _products = new()
    {
        new BankProduct { Id = 1, Name = "Сберегательный вклад",   Description = "Вклад с ежемесячной капитализацией процентов", InterestRate = 12.5m, IsActive = true },
        new BankProduct { Id = 2, Name = "Потребительский кредит", Description = "Кредит наличными без залога до 5 лет",        InterestRate = 21.0m, IsActive = true },
        new BankProduct { Id = 3, Name = "Ипотека",                Description = "Ипотечный кредит на покупку жилья",           InterestRate = 9.0m,  IsActive = true },
        new BankProduct { Id = 4, Name = "Кредитная карта",        Description = "Карта с льготным периодом 56 дней",           InterestRate = 29.9m, IsActive = true },
        new BankProduct { Id = 5, Name = "Автокредит",             Description = "Кредит на покупку автомобиля",                InterestRate = 16.0m, IsActive = false }
    };

    private int _nextId = 6;
    private readonly object _lock = new();

    public IEnumerable<BankProduct> GetAll()
    {
        lock (_lock) return _products.ToList();
    }

    public BankProduct? GetById(int id)
    {
        lock (_lock) return _products.FirstOrDefault(p => p.Id == id);
    }

    public BankProduct Create(BankProduct product)
    {
        lock (_lock)
        {
            product.Id = _nextId++;
            _products.Add(product);
            return product;
        }
    }

    public bool Update(int id, BankProduct product)
    {
        lock (_lock)
        {
            var existing = _products.FirstOrDefault(p => p.Id == id);
            if (existing is null) return false;

            existing.Name = product.Name;
            existing.Description = product.Description;
            existing.InterestRate = product.InterestRate;
            existing.IsActive = product.IsActive;
            return true;
        }
    }

    public bool Delete(int id)
    {
        lock (_lock)
        {
            var existing = _products.FirstOrDefault(p => p.Id == id);
            if (existing is null) return false;
            _products.Remove(existing);
            return true;
        }
    }
}
