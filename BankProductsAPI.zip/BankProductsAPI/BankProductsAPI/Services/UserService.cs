using BankProductsAPI.Models;

namespace BankProductsAPI.Services;

/// <summary>
/// Хранение и получение тестовых пользователей (в памяти).
/// </summary>
public class UserService : IUserService
{
    private readonly List<User> _users = new()
    {
        new User { Id = 1, UserName = "AdminUser",   Password = "Admin123",   Email = "admin@bank.kz",   Roles = new() { "Admin" } },
        new User { Id = 2, UserName = "ManagerUser", Password = "Manager123", Email = "manager@bank.kz", Roles = new() { "Manager" } },
        new User { Id = 3, UserName = "ClientUser",  Password = "Client123",  Email = "client@bank.kz",  Roles = new() { "Client" } }
    };

    public IEnumerable<User> GetAll() => _users;

    public User? ValidateCredentials(string userName, string password)
    {
        // Логин регистронезависимый, пароль — строгое сравнение
        return _users.FirstOrDefault(u =>
            string.Equals(u.UserName, userName, StringComparison.OrdinalIgnoreCase) &&
            u.Password == password);
    }
}
