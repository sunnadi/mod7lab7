using BankProductsAPI.Models;

namespace BankProductsAPI.Services;

public interface IUserService
{
    User? ValidateCredentials(string userName, string password);
    IEnumerable<User> GetAll();
}
